import java.util.ArrayList;
import java.util.List;

public class Combination
{
    public static List<List<Integer>> combination(int n, int k)
    {
        List<List<Integer>> result = new ArrayList<>();
        inputArray(1, n, k, new ArrayList<>(), result);
        return result;
    }
    private static void inputArray(int start, int n, int k, List<Integer> list,
                                   List<List<Integer>> result)
    {
        if (list.size() == k) {
            result.add(new ArrayList<>(list));
            return;
        }

        for (int i = start; i <= n; i++) {

            list.add(i);

            inputArray(i + 1, n, k, list, result);

            list.remove(list.size() - 1);
        }
    }
}
