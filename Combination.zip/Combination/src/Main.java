import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Combination solution = new Combination();

        // Test case 1: n=4, k=2
        List<List<Integer>> result = solution.combination(4, 2);
        System.out.println("Test case 1 (n = 4, k = 2): " + result);

        // Test case 2: n=1, k=1
        List<List<Integer>> result1 = solution.combination(1, 1);
        System.out.println("Test case 2 (n = 1, k = 1): " + result1);

    }
}



